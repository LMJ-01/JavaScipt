// 지도 초기화 함수
function initMap() {
  var mapContainer = document.getElementById('map'); // 지도 컨테이너 가져오기
  var options = {
    center: new kakao.maps.LatLng(37.5665, 126.9780), // 지도 중심 좌표 설정 (서울)
    level: 10 // 기본 줌 레벨 설정
  };

  var map = new kakao.maps.Map(mapContainer, options); // 지도 객체 생성

  // API에서 받아올 데이터의 URL
  var apiUrl = 'https://apis.data.go.kr/1741000/TsunamiShelter3';
  var apiKey = 'SQdZxeb8FMQlwXvNZl2NzbSTOmpaXa3L95W5XyCWDDUonxDo8XAFjF26St3KDgq61b2CzGouI5nmIUC4kTWwJQ%3D%3D'; // 공공데이터 포털에서 발급받은 인증키

  // API 요청을 보내는 함수
  function fetchData() {
    var requestUrl = apiUrl + '?ServiceKey=' + apiKey + '&type=json'; // 요청 URL 생성

    fetch(requestUrl)
      .then(function(response) {
        return response.json();
      })
      .then(function(data) {
        // 받아온 데이터를 처리하여 마커로 지도에 표시
        var shelterList = data.TsunamiShelter[1].row; // 데이터에서 대피장소 목록 가져오기

        // 대피장소 목록을 순회하며 마커 표시
        shelterList.forEach(function(shelter) {
          var markerPosition = new kakao.maps.LatLng(shelter.위도, shelter.경도); // 대피장소의 위도와 경도 정보
          var marker = new kakao.maps.Marker({
            map: map,
            position: markerPosition,
            title: shelter.시설명 // 대피장소 이름을 마커 타이틀로 설정
          });
        });
      })
      .catch(function(error) {
        console.error('데이터를 불러오는 데 실패했습니다.', error);
      });
  }

  fetchData(); // 데이터 요청 함수 호출
}

// 페이지 로드 시 initMap 함수 호출
document.addEventListener('DOMContentLoaded', function () {
  initMap();
});
